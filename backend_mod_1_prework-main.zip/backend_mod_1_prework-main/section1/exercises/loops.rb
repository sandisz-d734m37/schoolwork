# In the below exercises, write code that achieves
# the desired result. To check your work, run this
# file by entering the following command in your terminal:
# `ruby section1/exercises/loops.rb`

# Example: Write code that prints your name five times:
5.times do
  p "Hermione Granger"
end

# Write code that prints the sum of 2 plus 2 seven times:
7.times do
  # YOUR CODE HERE
end

# Write code that prints the phrase 'She sells seashells down by the seashore'
# ten times:
# YOUR CODE HERE


# Write code that prints the result of 5 + 7 a total of 9 timees
# YOUR CODE HERE
