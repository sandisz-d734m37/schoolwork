#-------------------
# BOOLEANS
#-------------------

# EXAMPLE: log to the console the result of 1 is equal to 2:
p 1 === 2

# EXAMPLE: log to the console the result of 7 is greater than 2:
p 7 > 2

# YOU DO: log to the console the result of "hello" is equal to "Hello":

# YOU DO: log to the console the result of 3 is not equal to 4:

# YOU DO: log to the console the result of 4 is less than or equal to 5:
