# In the below exercises, write code that achieves
# the desired result. To check your work, run this
# file by entering the following command in your terminal:
# `ruby section1/exercises/numbers.rb`

# Example: Write code that prints the result of the sum of 2 and 2:
p 2 + 2

# Write code that prints the result of 7 subtracted from 83:
p #YOUR CODE HERE

# Write code that prints the result of 6 multiplied by 53:
# YOUR CODE HERE

# Write code that prints the result of the modulo of 10 into 54:
# YOUR CODE HERE
